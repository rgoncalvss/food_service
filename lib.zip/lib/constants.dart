import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFB00202);
const kPrimaryLightColor = Color(0xFFFFC05A);
const backGroundColor = Color(0xFFE3DDD1);

const double defaultPadding = 14.0;
